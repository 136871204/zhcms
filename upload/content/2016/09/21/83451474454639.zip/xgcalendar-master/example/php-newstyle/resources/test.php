<?php
	$use_flag['zh'] = 'cn';
?>
