<?php

define('EC_CHARSET','utf-8');

define('ADMIN_PATH','admin');

define('AUTH_KEY', 'zhshop');

define('OLD_AUTH_KEY', 'zhshop1');

define('API_TIME', '2016-01-29 03:36:25');

?>