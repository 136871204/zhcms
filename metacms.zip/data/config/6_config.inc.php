<?php if (!defined('ZHPHP_PATH')) exit; 
return array (
  '6_WEBNAME' => 'HIS 分店',
  '6_WEB_TITLE' => 'HIS 其他',
  '6_KEYWORDS' => 'HIS 其他 SEO关键字',
  '6_DESCRIPTION' => 'HIS其他 SEO说明',
  '6_WEICHAT_QR' => 'upload/original/config/2015/09/16/21111442390502.jpg',
  '6_WEIBO_LINK' => 'http://otherweibo.com/u/1594449317/home?wvr=5&sudaref=www.baidu.com',
  '6_ALLDAY_PHONE' => '400-6666-6666',
);
?>