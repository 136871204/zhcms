<?php if (!defined('ZHPHP_PATH')) exit; 
return array (
  '2_WEBNAME' => 'HIS 上海支店',
  '2_WEB_TITLE' => 'HIS 上海',
  '2_KEYWORDS' => 'HIS上海 SEO关键字',
  '2_DESCRIPTION' => 'HIS 上海 SEO说明',
  '2_WEICHAT_QR' => 'upload/original/config/2015/09/16/2971442390187.jpg',
  '2_WEIBO_LINK' => 'http://shanghaiweibo.com/u/1594449317/home?wvr=5&sudaref=www.baidu.com',
  '2_ALLDAY_PHONE' => '400-2222-2222',
);
?>