<?php if (!defined('ZHPHP_PATH'))exit('No direct script access allowed');
return array (
  'DB_DRIVER' => 'mysqli',
  'DB_HOST' => 'localhost',
  'DB_PORT' => 3306,
  'DB_USER' => 'root',
  'DB_PASSWORD' => '',
  'DB_DATABASE' => 'works',
  'DB_PREFIX' => 'zh_',
  'WEB_MASTER' => 'test',
  'VERSION' => 'ZHCMS 简体中文 UTF8 版  2014.06.10',
);
?>