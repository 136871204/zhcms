<?php if (!defined('ZHPHP_PATH')) exit; 
return array (
  '5_WEBNAME' => 'HIS 苏州支店',
  '5_WEB_TITLE' => 'HIS 苏州',
  '5_KEYWORDS' => 'HIS 苏州 SEO关键字',
  '5_DESCRIPTION' => 'HIS苏州 SEO说明',
  '5_WEICHAT_QR' => 'upload/original/config/2015/09/16/7171442390207.jpg',
  '5_WEIBO_LINK' => 'http://suzhouweibo.com/u/1594449317/home?wvr=5&sudaref=www.baidu.com',
  '5_ALLDAY_PHONE' => '400-5555-5555',
);
?>