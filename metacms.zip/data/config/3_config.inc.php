<?php if (!defined('ZHPHP_PATH')) exit; 
return array (
  '3_WEBNAME' => 'HIS 北京支店',
  '3_WEB_TITLE' => 'HIS 北京',
  '3_KEYWORDS' => 'HIS北京 SEO关键字',
  '3_DESCRIPTION' => 'HIS北京 SEO说明',
  '3_WEICHAT_QR' => 'upload/original/config/2015/09/16/11691442390199.jpg',
  '3_WEIBO_LINK' => 'http://beijingweibo.com/u/1594449317/home?wvr=5&sudaref=www.baidu.com',
  '3_ALLDAY_PHONE' => '400-3333-3333',
);
?>