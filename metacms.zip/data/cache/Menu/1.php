<?php if(!defined('ZHPHP_PATH'))exit;
return array (
  0 => 
  array (
    'uid' => '1',
    'nid' => '20',
    'title' => 'menu_title_t3_system_setting_site',
    'app_group' => 'Zhcms',
    'app' => 'Admin',
    'control' => 'Config',
    'method' => 'edit',
    'param' => '',
    'comment' => '',
    'state' => '1',
    'type' => '1',
    'pid' => '19',
    'list_order' => '90',
    'is_system' => '0',
    'favorite' => '0',
  ),
  1 => 
  array (
    'uid' => '1',
    'nid' => '13',
    'title' => 'menu_title_t3_content_manage_category_manage',
    'app_group' => 'Zhcms',
    'app' => 'Admin',
    'control' => 'Category',
    'method' => 'index',
    'param' => '',
    'comment' => '',
    'state' => '1',
    'type' => '1',
    'pid' => '2',
    'list_order' => '20',
    'is_system' => '0',
    'favorite' => '1',
  ),
);
?>