<?php if(!defined('ZHPHP_PATH'))exit;
return array (
  0 => '人気',
  1 => 'トップ',
  2 => '推薦',
  3 => '画像',
  4 => 'エキス',
  5 => 'スライド',
  6 => 'マスタ推薦',
);
?>