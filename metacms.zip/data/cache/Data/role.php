<?php if(!defined('ZHPHP_PATH'))exit;
return array (
  0 => 
  array (
    'rid' => '1',
    'rname' => 'スーパー管理者',
    'title' => 'スーパー管理者',
    'admin' => '1',
    'system' => '1',
    'creditslower' => '10000',
    'comment_state' => '1',
    'allowsendmessage' => '1',
  ),
  1 => 
  array (
    'rid' => '2',
    'rname' => '内容編集者',
    'title' => '内容編集者',
    'admin' => '1',
    'system' => '1',
    'creditslower' => '10000',
    'comment_state' => '1',
    'allowsendmessage' => '1',
  ),
  2 => 
  array (
    'rid' => '3',
    'rname' => '発表スタッフ',
    'title' => '発表スタッフ',
    'admin' => '1',
    'system' => '1',
    'creditslower' => '10000',
    'comment_state' => '1',
    'allowsendmessage' => '1',
  ),
  3 => 
  array (
    'rid' => '4',
    'rname' => 'Level0',
    'title' => '游客',
    'admin' => '0',
    'system' => '1',
    'creditslower' => '0',
    'comment_state' => '0',
    'allowsendmessage' => '0',
  ),
  4 => 
  array (
    'rid' => '5',
    'rname' => 'Level1',
    'title' => '新手上路',
    'admin' => '0',
    'system' => '0',
    'creditslower' => '100',
    'comment_state' => '1',
    'allowsendmessage' => '1',
  ),
  5 => 
  array (
    'rid' => '6',
    'rname' => 'Level2',
    'title' => '小学生',
    'admin' => '0',
    'system' => '0',
    'creditslower' => '250',
    'comment_state' => '1',
    'allowsendmessage' => '1',
  ),
  6 => 
  array (
    'rid' => '7',
    'rname' => 'Level3',
    'title' => '中学生',
    'admin' => '0',
    'system' => '0',
    'creditslower' => '450',
    'comment_state' => '1',
    'allowsendmessage' => '1',
  ),
  7 => 
  array (
    'rid' => '8',
    'rname' => 'Level4',
    'title' => '高中生',
    'admin' => '0',
    'system' => '0',
    'creditslower' => '700',
    'comment_state' => '1',
    'allowsendmessage' => '1',
  ),
  8 => 
  array (
    'rid' => '9',
    'rname' => 'Level5',
    'title' => '大学生',
    'admin' => '0',
    'system' => '0',
    'creditslower' => '1050',
    'comment_state' => '1',
    'allowsendmessage' => '1',
  ),
  9 => 
  array (
    'rid' => '10',
    'rname' => 'Level6',
    'title' => '研究生',
    'admin' => '0',
    'system' => '0',
    'creditslower' => '1450',
    'comment_state' => '1',
    'allowsendmessage' => '1',
  ),
  10 => 
  array (
    'rid' => '27',
    'rname' => '社員テスト',
    'title' => '会社会員内部テスト用',
    'admin' => '1',
    'system' => '0',
    'creditslower' => '0',
    'comment_state' => '1',
    'allowsendmessage' => '1',
  ),
  11 => 
  array (
    'rid' => '28',
    'rname' => 'Level7',
    'title' => '',
    'admin' => '0',
    'system' => '0',
    'creditslower' => '2000',
    'comment_state' => '0',
    'allowsendmessage' => '0',
  ),
);
?>