<?php if(!defined('ZHPHP_PATH'))exit;
return array (
  0 => 
  array (
    'id' => '1',
    'webid' => '1',
    'aid' => '1',
    'lowerprice' => NULL,
    'highprice' => '2000',
  ),
  1 => 
  array (
    'id' => '2',
    'webid' => '1',
    'aid' => NULL,
    'lowerprice' => '2001',
    'highprice' => '4000',
  ),
  2 => 
  array (
    'id' => '3',
    'webid' => '1',
    'aid' => '2',
    'lowerprice' => '4001',
    'highprice' => '6000',
  ),
  3 => 
  array (
    'id' => '5',
    'webid' => '1',
    'aid' => '4',
    'lowerprice' => '5001',
    'highprice' => '10000',
  ),
  4 => 
  array (
    'id' => '4',
    'webid' => '1',
    'aid' => '3',
    'lowerprice' => '6001',
    'highprice' => '8000',
  ),
  5 => 
  array (
    'id' => '6',
    'webid' => '1',
    'aid' => '5',
    'lowerprice' => '8001',
    'highprice' => '10000',
  ),
  6 => 
  array (
    'id' => '17',
    'webid' => '1',
    'aid' => NULL,
    'lowerprice' => '10000',
    'highprice' => NULL,
  ),
);
?>