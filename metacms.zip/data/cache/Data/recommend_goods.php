<?php if(!defined('ZHPHP_PATH'))exit;
return array (
  'best' => 
  array (
    0 => 
    array (
      'goods_id' => '56',
      'sort_order' => '100',
    ),
    1 => 
    array (
      'goods_id' => '64',
      'sort_order' => '100',
    ),
    2 => 
    array (
      'goods_id' => '55',
      'sort_order' => '100',
    ),
    3 => 
    array (
      'goods_id' => '57',
      'sort_order' => '100',
    ),
    4 => 
    array (
      'goods_id' => '59',
      'sort_order' => '100',
    ),
  ),
  'new' => 
  array (
    0 => 
    array (
      'goods_id' => '54',
      'sort_order' => '100',
    ),
    1 => 
    array (
      'goods_id' => '55',
      'sort_order' => '100',
    ),
  ),
  'hot' => 
  array (
    0 => 
    array (
      'goods_id' => '58',
      'sort_order' => '100',
    ),
  ),
  'brand' => 
  array (
    56 => 'バンダイ',
    64 => 'バンダイ',
    54 => '天馬Fits',
    55 => '不二貿易',
    57 => 'FRIEND STREET',
    58 => 'バンダイ',
    59 => 'FRIEND STREET',
  ),
);
?>