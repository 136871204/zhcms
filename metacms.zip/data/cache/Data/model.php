<?php if(!defined('ZHPHP_PATH'))exit;
return array (
  1 => 
  array (
    'mid' => '1',
    'model_name' => '普通文章',
    'table_name' => 'content',
    'enable' => '1',
    'description' => '',
    'is_system' => '1',
  ),
  19 => 
  array (
    'mid' => '19',
    'model_name' => 'ニュース',
    'table_name' => 'news',
    'enable' => '1',
    'description' => 'ニュース',
    'is_system' => '0',
  ),
);
?>