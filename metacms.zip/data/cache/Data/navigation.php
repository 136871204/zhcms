<?php if(!defined('ZHPHP_PATH'))exit;
return array (
  5 => 
  array (
    'nid' => '5',
    'title' => '中国',
    'pid' => '0',
    'target' => '_self',
    'state' => '1',
    'list_order' => '100',
    'url' => '[ROOT]/ch',
    '_level' => 1,
    '_html' => '',
    '_name' => '中国',
  ),
  6 => 
  array (
    'nid' => '6',
    'title' => '简体',
    'pid' => '5',
    'target' => '_self',
    'state' => '1',
    'list_order' => '100',
    'url' => '[ROOT]/ch/1',
    '_level' => 2,
    '_html' => '',
    '_first' => true,
    '_end' => false,
    '_name' => '├─ 简体',
  ),
  7 => 
  array (
    'nid' => '7',
    'title' => '繁体',
    'pid' => '5',
    'target' => '_self',
    'state' => '1',
    'list_order' => '100',
    'url' => '[ROOT]/ch/2',
    '_level' => 2,
    '_html' => '',
    '_first' => false,
    '_end' => true,
    '_name' => '└─ 繁体',
  ),
  8 => 
  array (
    'nid' => '8',
    'title' => '日本',
    'pid' => '0',
    'target' => '_self',
    'state' => '1',
    'list_order' => '100',
    'url' => '[ROOT]/jp',
    '_level' => 1,
    '_html' => '',
    '_name' => '日本',
  ),
);
?>