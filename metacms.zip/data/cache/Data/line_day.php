<?php if(!defined('ZHPHP_PATH'))exit;
return array (
  0 => 
  array (
    'id' => '1',
    'webid' => '1',
    'aid' => '1',
    'word' => '1',
    'isdisplay' => '1',
  ),
  1 => 
  array (
    'id' => '2',
    'webid' => '1',
    'aid' => '2',
    'word' => '2',
    'isdisplay' => '1',
  ),
  2 => 
  array (
    'id' => '3',
    'webid' => '1',
    'aid' => '3',
    'word' => '3',
    'isdisplay' => '1',
  ),
  3 => 
  array (
    'id' => '4',
    'webid' => '1',
    'aid' => '4',
    'word' => '4',
    'isdisplay' => '1',
  ),
  4 => 
  array (
    'id' => '5',
    'webid' => '1',
    'aid' => '5',
    'word' => '5',
    'isdisplay' => '1',
  ),
  5 => 
  array (
    'id' => '6',
    'webid' => '1',
    'aid' => '6',
    'word' => '6',
    'isdisplay' => '1',
  ),
  6 => 
  array (
    'id' => '7',
    'webid' => '1',
    'aid' => '7',
    'word' => '7',
    'isdisplay' => '1',
  ),
  7 => 
  array (
    'id' => '8',
    'webid' => '1',
    'aid' => '8',
    'word' => '8',
    'isdisplay' => '1',
  ),
  8 => 
  array (
    'id' => '9',
    'webid' => '1',
    'aid' => '9',
    'word' => '9',
    'isdisplay' => '1',
  ),
  9 => 
  array (
    'id' => '10',
    'webid' => '1',
    'aid' => '10',
    'word' => '10',
    'isdisplay' => '1',
  ),
);
?>