<?php if(!defined('ZHPHP_PATH'))exit;
return array (
  0 => 
  array (
    'id' => '1',
    'webname' => '中国',
    'weburl' => 'http://admin.his.com/',
    'webid' => '0',
    'webroot' => 'china',
    'webprefix' => 'www',
    'is_main' => '0',
    'name1' => '',
    'displayorder' => '9999',
  ),
  1 => 
  array (
    'id' => '2',
    'webname' => '上海支店',
    'weburl' => 'http://admin.his.com/shanghai',
    'webid' => NULL,
    'webroot' => 'shanghai',
    'webprefix' => 'shanghai',
    'is_main' => '1',
    'name1' => '',
    'displayorder' => '9999',
  ),
  2 => 
  array (
    'id' => '3',
    'webname' => '北京支店',
    'weburl' => 'http://admin.his.com/beijing',
    'webid' => NULL,
    'webroot' => 'beijing',
    'webprefix' => 'beijing',
    'is_main' => '1',
    'name1' => '',
    'displayorder' => '9999',
  ),
  3 => 
  array (
    'id' => '6',
    'webname' => '其他支店',
    'weburl' => 'http://admin.his.com/other',
    'webid' => NULL,
    'webroot' => 'other',
    'webprefix' => 'other',
    'is_main' => '1',
    'name1' => '',
    'displayorder' => '9999',
  ),
);
?>