<?php if (!defined("VERSION")) exit; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title><?php echo $step[3]; ?></title>
    <link type="text/css" href="./template/css/css.css" rel="stylesheet"/>
</head>
<body>
<div class="step3 step" style="height: 550px;">
    <div class="title">ZHCMS　インストールナビー</div>
    <div class="process">
        <ul>
            <li class="current">許可協議</li>
            <li>環境check</li>
            <li>DB設定</li>
            <li>データ作成</li>
            <li>完了</li>
        </ul>
    </div>
    <!--协议说明-->
    <div class="license">
        <h1>日本語版許可協議、日本をお客さんを利用する</h1>

        <p>著作権：Metaphase</p>

        <p>ZHCMSの商品利用すること感謝します、商品完璧にすることを頑張ります、我々のサイトはwww.metaphase.co.jp</p>

        <p>
            説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一説明一</p>

        <p>説明二説明二説明二説明二説明二説明二説明二説明二説明二説明二説明二説明二説明二説明二説明二説明二説明二説明二説明二説明二説明二説明二説明二説明二</p>

        <p>説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3説明3</p>

        <p></p>

        <p>説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4説明4</p>

        
    </div>
    <!--协议说明-->
    <div class="btn">
        <a href="?step=2">前へ</a><a href="?step=4">次へ</a>
    </div>
</div>
</div>
</body>
</html>