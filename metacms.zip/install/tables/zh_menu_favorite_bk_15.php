<?php if(!defined('ZHPHP_PATH'))EXIT;
$db->exe("REPLACE INTO ".$db_prefix."menu_favorite (`uid`,`nid`) VALUES('1','13')");
$db->exe("REPLACE INTO ".$db_prefix."menu_favorite (`uid`,`nid`) VALUES('1','4')");
$db->exe("REPLACE INTO ".$db_prefix."menu_favorite (`uid`,`nid`) VALUES('1','180')");
$db->exe("REPLACE INTO ".$db_prefix."menu_favorite (`uid`,`nid`) VALUES('1','61')");
$db->exe("REPLACE INTO ".$db_prefix."menu_favorite (`uid`,`nid`) VALUES('1','12')");
$db->exe("REPLACE INTO ".$db_prefix."menu_favorite (`uid`,`nid`) VALUES('1','20')");
