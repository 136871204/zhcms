<?php if(!defined('ZHPHP_PATH'))EXIT;
$db->exe("REPLACE INTO ".$db_prefix."plugin (`pid`,`name`,`install_time`,`version`,`team`,`app`,`email`,`web`,`pubdate`) VALUES('18','友情链接','2014-07-02','1.0','周鸿','Link','hong@metaphase.co.jp','www.metaphase.co.jp','2014-02-09')");
