<?php if(!defined('ZHPHP_PATH'))EXIT;
