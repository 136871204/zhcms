<?php if(!defined('ZHPHP_PATH'))EXIT;
$db->exe("REPLACE INTO ".$db_prefix."content_data (`aid`,`content`) VALUES('7','<p>ZHCMSをよりよく使えるために</p><p>定期的には、ビデオの形で講座を行います。期待してください<br/></p>')");
$db->exe("REPLACE INTO ".$db_prefix."content_data (`aid`,`content`) VALUES('6','<p>ZHCMS</p><p>ZHCMS（内容管理システム）は、どんなサイトでも（一切商業ウェブサイトも含め）無料で使える、100%オープンソース，100%無料！</p><p>そして、ビデオで使用方を教えて差し上げます。</p><p><br/></p>')");
$db->exe("REPLACE INTO ".$db_prefix."content_data (`aid`,`content`) VALUES('8','<p>ZHCMSのBug提供、有難うございます</p><p><br/></p><p>ZHCMSはテストバージョンと、これからの発展はみんなの協力が必要もなる。</p><p>たぶんいろいろなBugがあると思います。</p><p>このカテゴリでBugを提供してもらいたいです。</p><p>ZHCMSももっと完璧な商品になるため、ZHチームもがんばります<br/></p>')");
