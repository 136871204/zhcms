<?php
header("location:index.php?a=Admin&c=Login&m=login");