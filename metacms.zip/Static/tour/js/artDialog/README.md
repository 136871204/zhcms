#	artDialog``v6``

artDialog v6 —— 经典的网页对话框组件，内外皆用心雕琢。

##	用户

四年来，有超过 40 万网站在使用 artDialog，其中不乏国内顶尖的产品：

*	[QQ空间 v8（腾讯）](http://qzone.qq.com)
*	[Phpcms（盛大）](http://www.phpcms.cn)
*	[极路由](http://www.hiwifi.com)

##	文档与示例

<http://aui.github.io/artDialog/doc/index.html>

##	兼容性

测试通过：IE6-IE11、Chrome、Firefox、Safari、Opera

##	授权协议

免费，且开源，基于[LGPL](./LICENSE.md)协议。

##	支持开源

[贡献代码](https://github.com/aui/artDialog) || [捐赠一杯咖啡](https://me.alipay.com/planeart) || [商业授权](./LICENSE.md)

artDialog，献给那些愿意为 web 极致体验付出的人们！